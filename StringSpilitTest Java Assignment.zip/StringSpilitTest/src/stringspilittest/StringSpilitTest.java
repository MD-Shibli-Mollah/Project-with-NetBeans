package stringspilittest;

import java.util.Scanner;

public class StringSpilitTest {

    private static int s;

    public static void main(String[] args) {
        Scanner input;
        input = new Scanner(System.in);
        String number = input.nextLine();

        Info(number);
    }

    private static void Info(String number) {
        String[] splitVal = number.split("");   //split method

        int id, semester;
        id = Integer.parseInt(splitVal[3]);      //spilit and array converted to int
        semester = Integer.parseInt(splitVal[4]);
        for (int i = 0; i <= 9; i++) {
            if (id == i) {
                switch (semester) {
                    case 0:
                        System.out.println("The student admitted in SPRING, year: 201" + i + " and student's ID is: " + number);
                        break;
                    case 1:
                        System.out.println("The student admitted in SUMMER, year: 201" + i + " and student's ID is: " + number);
                        break;
                    case 2:
                        System.out.println("The student admitted in FALL, year: 201" + i + " and student's ID is: " + number);
                        break;
                    default:
                        break;
                }
            }
        }
    }
}