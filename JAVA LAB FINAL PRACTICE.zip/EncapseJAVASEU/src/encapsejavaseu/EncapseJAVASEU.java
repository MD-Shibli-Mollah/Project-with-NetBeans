
package encapsejavaseu;

public class EncapseJAVASEU {

    public static void main(String[] args) {
        A obj = new A();
        
        obj.setI("Tanvir");
        System.out.println("Here I am "+ obj.getI());
    }
    
}
