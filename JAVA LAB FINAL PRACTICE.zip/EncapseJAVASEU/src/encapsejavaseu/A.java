
package encapsejavaseu;


public class A {
    String i = "MD Shibli Mollah";

    public void setI(String i) {
        this.i = i;
    }
    
    
    public String getI() {
        return i;
    }
    
    
    
    
}
