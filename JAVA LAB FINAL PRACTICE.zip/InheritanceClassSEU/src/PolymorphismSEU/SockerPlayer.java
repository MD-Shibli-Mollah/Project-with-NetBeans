package PolymorphismSEU;

public class SockerPlayer {
    

    void Striker() {
        System.out.println("Good Stiker");
    }

    void Striker(String name) {
        System.out.println("The name of the Striker is " + name);
    }

}
